// MainActivity.java
package com.example.usbcamerarecorder;

import static android.os.Environment.getExternalStoragePublicDirectory;

import android.Manifest;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.serenegiant.usb.USBMonitor;
import com.serenegiant.usb.UVCCamera;
import com.serenegiant.usb.widget.UVCCameraTextureView;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "USBCamera";
    private static final int REQUEST_PERMISSIONS = 1;
    private static final int WIDTH = 640;
    private static final int HEIGHT = 480;

    private TextView tvDeviceStatus;
    private UVCCamera uvcCamera;
    private USBMonitor usbMonitor;
    private Button btnRecord;
    private TextView tvFps;
    private boolean isRecording = false;
    private UVCCameraTextureView cameraView;
    private Surface previewSurface;
    private Surface recordingSurface;
    private SimpleVideoRecorder videoRecorder;
    private Context context;

    private FpsCalculator fpsCalculator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();

        MyLogger.init(this);
        MyLogger.log("Application started");

        initViews();
        setupSurfaceListener();

        // +++ ДОБАВЛЕНО +++
        initFpsCalculator();

        if (checkPermissions()) {
            initUSBCamera();
            checkConnectedDevices();
        } else {
            requestPermissions();
        }


        setupRecordButton();
    }

    private void initFpsCalculator() {
        fpsCalculator = new FpsCalculator();
        fpsCalculator.setListener(fps -> {
            runOnUiThread(() -> {
                String status = isRecording ? "Recording" : "Preview";
                tvFps.setText(String.format("FPS: %.1f (%s)", fps, status));
            });
        });
    }

    private void initViews() {
        btnRecord = findViewById(R.id.btn_record);
        tvFps = findViewById(R.id.tv_fps);
        tvDeviceStatus = findViewById(R.id.tv_device_status);
        tvDeviceStatus.setText("Waiting for USB device");
        cameraView = findViewById(R.id.camera_view);
    }

    private void setupSurfaceListener() {
        cameraView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
                MyLogger.log("Surface available: " + width + "x" + height);
                surface.setDefaultBufferSize(WIDTH, HEIGHT);
                synchronized (cameraLock) {
                    if (previewSurface != null) {
                        previewSurface.release();
                        previewSurface = null;
                    }
                    previewSurface = new Surface(surface);
                    if (uvcCamera != null && !isRecording) {
                        tryStartPreview();
                    }
                }
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
                if (previewSurface != null) {
                    previewSurface.release();
                    previewSurface = null;
                }
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surface) {

            }
        });
    }

    private void tryStartPreview() {
        synchronized (cameraLock) {
            if (uvcCamera == null) {
                MyLogger.log("tryStartPreview: Camera is null");
                return;
            }

            if (previewSurface == null || !previewSurface.isValid()) {
                MyLogger.log("tryStartPreview: Surface is " +
                        (previewSurface == null ? "null" : "invalid"));
                return;
            }

            if (isRecording) {
                MyLogger.log("tryStartPreview: Skipping - recording in progress");
                return;
            }

            try {
                uvcCamera.setPreviewDisplay(previewSurface);
                uvcCamera.startPreview();
                MyLogger.log("Preview started successfully");
                runOnUiThread(() -> {
                    btnRecord.setEnabled(true);
                    Toast.makeText(MainActivity.this, "Camera preview started", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                MyLogger.log("Preview start error: " + e.getMessage());
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "Preview error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    private void checkConnectedDevices() {
        UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        HashMap<String, UsbDevice> deviceList = usbManager.getDeviceList();

        if (deviceList.isEmpty()) {
            MyLogger.log("No USB devices found");
            runOnUiThread(() -> tvDeviceStatus.setText("No devices connected"));
        } else {
            for (UsbDevice device : deviceList.values()) {
                MyLogger.log("Found device: " + device.getDeviceName() + " VID: " + String.format("0x%04X", device.getVendorId()) + " PID: " + String.format("0x%04X", device.getProductId()));
                if (isUvcDevice(device)) {
                    showDeviceAlert(device);
                    usbMonitor.requestPermission(device);
                    break;
                }
            }
        }
    }

    private void showDeviceAlert(UsbDevice device) {
        runOnUiThread(() -> {
            new AlertDialog.Builder(this)
                    .setTitle("UVC Camera Connected")
                    .setMessage(String.format(
                            "Name: %s\nVID: 0x%04X\nPID: 0x%04X",
                            device.getDeviceName(),
                            device.getVendorId(),
                            device.getProductId()))
                    .setPositiveButton("OK", null)
                    .show();

            tvDeviceStatus.setText("Device connected");
            btnRecord.setEnabled(true);
        });
    }

    private boolean isUvcDevice(UsbDevice device) {
        return device.getDeviceClass() == 239 || device.getDeviceSubclass() == 2;
    }


    private boolean checkPermissions() {
        String[] required = {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.WRITE_EXTERNAL_STORAGE // Для API < 29
        };

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            required = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
            };
        }


        for (String perm : required) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                MyLogger.log("Permission missing: " + perm);
                return false;
            }
        }
        return true;
    }

    private void requestPermissions() {
        String[] permissionsToRequest = {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.WRITE_EXTERNAL_STORAGE // Для API < 29
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissionsToRequest = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO
            };
        }

        ActivityCompat.requestPermissions(this,
                permissionsToRequest,
                REQUEST_PERMISSIONS);
    }

    private void initUSBCamera() {
        usbMonitor = new USBMonitor(this, new USBMonitor.OnDeviceConnectListener() {
            @Override
            public void onAttach(UsbDevice device) {
                MyLogger.log("Device attached: " + device.getDeviceName());
                if (isUvcDevice(device)) {
                    showDeviceAlert(device);
                    usbMonitor.requestPermission(device);
                }
            }

            @Override
            public void onConnect(UsbDevice device, USBMonitor.UsbControlBlock ctrlBlock, boolean createNew) {
                MyLogger.log("Device connected: " + device.getDeviceName());
                openCamera(ctrlBlock);
            }

            @Override
            public void onDisconnect(UsbDevice device, USBMonitor.UsbControlBlock ctrlBlock) {
                MyLogger.log("Device disconnected: " + device.getDeviceName());
                closeCamera();
                runOnUiThread(() -> {
                    tvDeviceStatus.setText("Disconnected");
                    btnRecord.setEnabled(false);
                });
            }

            @Override
            public void onDettach(UsbDevice device) {
                MyLogger.log("Device detached: " + device.getDeviceName());
                closeCamera();
            }

            @Override
            public void onCancel(UsbDevice device) {
                MyLogger.log("Permission canceled for device: " + device.getDeviceName());
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "USB permission denied", Toast.LENGTH_SHORT).show());
            }
        });

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Field field = USBMonitor.class.getDeclaredField("mPermissionIntent");
                field.setAccessible(true);
                Intent intent = new Intent("com.serenegiant.USB_PERMISSION." + usbMonitor.hashCode());
                intent.setPackage(getPackageName());
                PendingIntent pi = PendingIntent.getBroadcast(this, 0, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                field.set(usbMonitor, pi);
            }
            usbMonitor.register();
            MyLogger.log("USBMonitor initialized and registered");
        } catch (Exception e) {
            MyLogger.log("USBMonitor initialization error: " + e.getMessage());
            runOnUiThread(() -> Toast.makeText(this, "USBMonitor init error: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }


    private final Object cameraLock = new Object();

    private void openCamera(USBMonitor.UsbControlBlock ctrlBlock) {
        synchronized (cameraLock) {
            try {
                closeCamera();
                uvcCamera = new UVCCamera();
                uvcCamera.open(ctrlBlock);
                uvcCamera.setPreviewSize(WIDTH, HEIGHT, UVCCamera.DEFAULT_PREVIEW_MODE);
                MyLogger.log("Camera opened successfully.");


                uvcCamera.setFrameCallback(frame -> {
                    if (fpsCalculator != null) {
                        fpsCalculator.frameProcessed();
                    }
                }, UVCCamera.PIXEL_FORMAT_NV21); // Формат не так важен, главное - сам колбэк

                tryStartPreview();
            } catch (Exception e) {
                MyLogger.log("Camera open error: " + e.getMessage());
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "Camera error: " + e.getMessage(), Toast.LENGTH_LONG).show());
                closeCamera();
            }
        }
    }

    private void closeCamera() {
        synchronized (cameraLock) {
            if (uvcCamera != null) {
                try {
                    uvcCamera.stopPreview();

                    uvcCamera.setFrameCallback(null, 0);
                    uvcCamera.destroy();
                    MyLogger.log("Camera closed.");
                } catch (Exception e) {
                    MyLogger.log("Camera close error: " + e.getMessage());
                } finally {
                    uvcCamera = null;
                }
            }
        }
    }


    private void setupRecordButton() {
        btnRecord.setOnClickListener(v -> {
            if (uvcCamera == null) {
                Toast.makeText(this, "Camera not ready!", Toast.LENGTH_SHORT).show();
                MyLogger.log("Attempted to record, but uvcCamera is null.");
                return;
            }
            if (!isRecording) {
                startRecording();
            } else {
                stopRecording();
            }
        });
    }

    private void startRecording() {
        synchronized (cameraLock) {
            if (isRecording || uvcCamera == null) {
                return;
            }


            if (fpsCalculator != null) {
                fpsCalculator.reset();
            }

            try {
                File outputDir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_MOVIES), "USBCameraRecorder");
                if (!outputDir.exists() && !outputDir.mkdirs()) {
                    throw new IOException("Failed to create directory: " + outputDir.getAbsolutePath());
                }

                File outputFile = new File(outputDir, "video_" + System.currentTimeMillis() + ".mp4");
                videoRecorder = new SimpleVideoRecorder();
                videoRecorder.startRecording(outputFile, WIDTH, HEIGHT, new SimpleVideoRecorder.Callback() {
                    @Override
                    public void onSurfaceReady(Surface surface) {
                        synchronized (cameraLock) {
                            if (uvcCamera == null) {
                                return;
                            }
                            recordingSurface = surface;


                            uvcCamera.setPreviewDisplay(recordingSurface);
                            uvcCamera.startPreview();

                            isRecording = true;
                            runOnUiThread(() -> {
                                btnRecord.setText("Stop");
                                Toast.makeText(context, "Recording started: " + outputFile.getName(), Toast.LENGTH_LONG).show();
                                tvDeviceStatus.setText("Recording...");
                            });
                        }
                    }

                    @Override
                    public void onError(String message) {
                        runOnUiThread(() -> {
                            Toast.makeText(context, "Recorder error: " + message, Toast.LENGTH_LONG).show();
                            Log.e(TAG, "SimpleVideoRecorder onError: " + message);
                            stopRecording();
                        });
                    }
                });
                MyLogger.log("SimpleVideoRecorder initiated.");

            } catch (Exception e) {
                Log.e(TAG, "Recording setup error", e);
                handleRecordingError(e);
            }
        }
    }

    private void stopRecording() {
        synchronized (cameraLock) {
            if (!isRecording) {
                return;
            }

            if (videoRecorder != null) {
                videoRecorder.stopRecording();
                videoRecorder = null;
            }

            isRecording = false;
            recordingSurface = null;

            runOnUiThread(() -> {
                btnRecord.setText("Record");
                tvDeviceStatus.setText("Device connected");
                Toast.makeText(MainActivity.this, "Recording stopped", Toast.LENGTH_SHORT).show();
            });

            if (fpsCalculator != null) {
                fpsCalculator.reset();
            }

            if (uvcCamera != null) {
                try {
                    uvcCamera.stopPreview();
                    tryStartPreview();
                } catch (Exception e) {
                    MyLogger.log("Error restarting preview after recording: " + e.getMessage());
                }
            }
        }
    }

    private void handleRecordingError(Exception e) {
        runOnUiThread(() -> {
            Toast.makeText(context, "Recording error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e(TAG, "handleRecordingError: " + e.getMessage(), e);
        });
        stopRecording();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                MyLogger.log("Permissions granted");
                initUSBCamera();
                checkConnectedDevices();
            } else {
                MyLogger.log("Permissions denied");
                runOnUiThread(() ->
                        Toast.makeText(this, "Permissions denied. Cannot operate camera.", Toast.LENGTH_LONG).show());
                finish();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (usbMonitor != null) {
            usbMonitor.register();
            MyLogger.log("USBMonitor registered in onStart.");
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (usbMonitor != null) {
            usbMonitor.unregister();
            MyLogger.log("USBMonitor unregistered in onStop.");
        }
        if (isRecording) {
            stopRecording();
        }
        closeCamera();
    }

    @Override
    protected void onDestroy() {
        if (isRecording) {
            stopRecording();
        }

        if (usbMonitor != null) {
            usbMonitor.unregister();
            MyLogger.log("USBMonitor unregistered in onDestroy.");
        }

        closeCamera();

        if (previewSurface != null) {
            previewSurface.release();
            previewSurface = null;
            MyLogger.log("previewSurface released in onDestroy.");
        }
        super.onDestroy();
        MyLogger.log("Application destroyed");
    }
}